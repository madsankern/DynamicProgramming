# DynamicProgramming
Overview of the files:
* solve_1d_model.ipynb solves the simple consumption saving model
* solve_dc_model.ipynb solves the extended consumption-housing model
* fd_lcp.py is a script that solves the consumption-housing model in continuous time
